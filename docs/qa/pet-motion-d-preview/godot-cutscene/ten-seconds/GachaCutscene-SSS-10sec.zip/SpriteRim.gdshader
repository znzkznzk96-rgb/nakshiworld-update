shader_type canvas_item;
render_mode unshaded;

uniform vec4 rim_color : source_color = vec4(1.0, 0.86, 0.53, 1.0);
uniform float rim_strength : hint_range(0.0, 1.0) = 0.0;
varying vec4 sprite_tint;

void vertex() {
	sprite_tint = COLOR;
}

void fragment() {
	vec4 texel = texture(TEXTURE, UV);
	vec2 px = TEXTURE_PIXEL_SIZE;
	float top = texture(TEXTURE, UV - vec2(0.0, px.y)).a;
	float left = texture(TEXTURE, UV - vec2(px.x, 0.0)).a;
	float edge = texel.a * (1.0 - min(top, left));
	vec3 base = texel.rgb * sprite_tint.rgb;
	COLOR = vec4(mix(base, rim_color.rgb, edge * rim_strength), texel.a * sprite_tint.a);
}
